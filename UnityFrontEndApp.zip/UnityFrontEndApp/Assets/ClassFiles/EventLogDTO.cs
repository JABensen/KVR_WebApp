using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class EventLogDTO
{
    public string Id { get; set; }
    public string TaskName { get; set; }
    public string EventType { get; set; }
    public double SecondsIntoTest { get; set; }
}

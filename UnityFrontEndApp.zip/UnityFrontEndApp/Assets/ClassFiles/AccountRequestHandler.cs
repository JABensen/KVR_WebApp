using Defective.JSON;
using KVR;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AccountRequestHandler
{
    public NetworkManager NetworkManager {  get; set; }

    public void Login(string username, string password, RequestReturnDelegate callback)
    {
        string url = this.NetworkManager.BaseURL + "api/professor/login";
        JSONObject ProfessorLoginRequest = new JSONObject();
        ProfessorLoginRequest.AddField("Username", username);
        ProfessorLoginRequest.AddField("Password", password);
        string json = ProfessorLoginRequest.ToString();
        this.NetworkManager.StartCoroutine(this.NetworkManager.PostRequestCoroutine(url, json, callback));
    }

    public void CreateAccount(string firstName, string lastName, string username, string password, RequestReturnDelegate callback)
    {
        string url = this.NetworkManager.BaseURL + "api/professor/create";
        JSONObject Professor = new JSONObject();
        Professor.AddField("FirstName", firstName);
        Professor.AddField("LastName", lastName);
        Professor.AddField("Username", username);
        Professor.AddField("HashedPassword", password);
        string json = Professor.ToString();
        this.NetworkManager.StartCoroutine(this.NetworkManager.PostRequestCoroutine(url, json, callback));
    }
}

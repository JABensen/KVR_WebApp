using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParentMetricListDTO
{
    public List<StudentMetricsDTO> StudentMetrics {  get; set; }
}

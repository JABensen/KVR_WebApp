using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class StudentMetricsDTO
{
    public string StudentName { get; set; }
    public List<EventLogDTO> EventLogs { get; set; }
}

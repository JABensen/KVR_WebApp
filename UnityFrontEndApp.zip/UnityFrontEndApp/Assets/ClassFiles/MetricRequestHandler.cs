using Defective.JSON;
using KVR;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MetricRequestHandler
{
    public NetworkManager NetworkManager { get; set; }

    public void GetMetrics(RequestReturnDelegate callback)
    {
        string url = this.NetworkManager.BaseURL + "api/professor/metrics?id=" + this.NetworkManager.MenuContext.UserId;
        this.NetworkManager.StartCoroutine(this.NetworkManager.GetRequestCoroutine(url, callback));
    }
}

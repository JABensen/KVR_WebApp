using KVR;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NavBar : MonoBehaviour
{
    private List<Button> buttons = new List<Button>();
    public void SetInitialValues(Pages pageEnum)
    {
        foreach(Transform childTransform in this.gameObject.transform)
        {
            Button button = childTransform.GetComponent<Button>();
            this.buttons.Add(button);
            if(this.buttons.Count - 1 == (int)pageEnum)
            {
                button.interactable = false;
            }
        }
        if(pageEnum == 0)
        {
            this.ToggleNavBar(false);
        }
    }

    public void ToggleButtonByIndex(bool turnOn, int index)
    {
        this.buttons[index].gameObject.SetActive(turnOn);
    }

    public void ToggleNavBar(bool turnOn)
    {
        this.gameObject.SetActive(turnOn);
    }
}

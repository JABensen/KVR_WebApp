using System.Collections.Generic;
using UnityEngine;
using KVR;

namespace KVR
{
    public enum Pages
    {
        Login = 0,
        Account = 1,
        Metrics = 2,
    }
}

public class MenuContext : MonoBehaviour //This class is effectively acting as the context in a finite state machine where each state is a different MenuPage.  
{
    [field: SerializeField] public string UserId { get; set; }
    [field: SerializeField] public string Username { get; set; }
    [field: SerializeField] public string FirstName { get; set; }
    [field: SerializeField] public string LastName { get; set; }
    [field: SerializeField] public string ClassKey { get; set; }

    private List<MenuPage> pages = new List<MenuPage>();
    private int currentPageIndex;
    [field: SerializeField] public NetworkManager NetworkManager { get; set; }

    private void Awake()
    {
        foreach(Transform childTransform in this.gameObject.transform)
        {
            MenuPage page = childTransform.GetComponent<MenuPage>();
            page.SetInitialValues(this);
            this.pages.Add(page);
            childTransform.gameObject.SetActive(false);
        }
        this.currentPageIndex = 0;
        this.pages[currentPageIndex].gameObject.SetActive(true);
    }

    public void ChangeActivePage(int index)
    {
        this.pages[currentPageIndex].gameObject.SetActive(false);
        this.currentPageIndex = index;
        this.pages[currentPageIndex].gameObject.SetActive(true);
    }
}

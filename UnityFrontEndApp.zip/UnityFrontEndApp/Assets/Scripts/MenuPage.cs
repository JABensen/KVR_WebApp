using System.Collections.Generic;
using UnityEngine;
using KVR;

public abstract class MenuPage : MonoBehaviour
{
    [SerializeField] protected Pages pageEnum;
    protected NavBar navBar;
    public MenuContext MenuContext { get; protected set; }
    protected static readonly int hierarchyIndexNavBar = 0;

    public void SetInitialValues(MenuContext menuContext)
    {
        this.MenuContext = menuContext;
        this.navBar = this.gameObject.transform.GetChild(hierarchyIndexNavBar).gameObject.GetComponent<NavBar>();
        this.navBar.SetInitialValues(this.pageEnum);
    }
}

using System.Collections;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;
using KVR;

namespace KVR
{
    public delegate void RequestReturnDelegate(bool condition, string message);
}

public class NetworkManager : MonoBehaviour
{
    [field: SerializeField] public MenuContext MenuContext {  get; set; }
    public AccountRequestHandler AccountRequestHandler { get; private set; } = new AccountRequestHandler();
    public MetricRequestHandler MetricRequestHandler { get; private set; } = new MetricRequestHandler();

    public string BaseURL { get; private set; }

    private void Awake()
    {
        this.AccountRequestHandler.NetworkManager = this;
        this.MetricRequestHandler.NetworkManager = this;
        this.BaseURL = "https://localhost:7144/"; //This is currently configured for a development environment.
    }

    public IEnumerator PostRequestCoroutine(string url, string json, RequestReturnDelegate callback)
    {
        using (var request = new UnityWebRequest(url, "POST"))
        {
            byte[] bodyRaw = Encoding.UTF8.GetBytes(json);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");

            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                bool requestSucceeded = true;
                string serverLog = request.downloadHandler.text;
                callback(requestSucceeded, serverLog);

            }
            else
            {
                bool requestSucceeded = false;
                string serverLog = request.downloadHandler.text;
                callback(requestSucceeded, serverLog);
            }
        }
    }

    public IEnumerator GetRequestCoroutine(string url, RequestReturnDelegate callback)
    {
        using (UnityWebRequest request = UnityWebRequest.Get(url))
        {
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            yield return request.SendWebRequest();
            if (request.result == UnityWebRequest.Result.Success)
            {
                bool requestSucceeded = true;
                string serverLog = request.downloadHandler.text;
                callback(requestSucceeded, serverLog);
            }
            else
            {
                bool requestSucceeded = false;
                string serverLog = request.downloadHandler.text;
                callback(requestSucceeded, serverLog);
            }
        }
    }

    public IEnumerator DeleteRequestCoroutine(string url, RequestReturnDelegate callback)
    {
        using (UnityWebRequest request = UnityWebRequest.Delete(url))
        {
            yield return request.SendWebRequest();
            if (request.result == UnityWebRequest.Result.Success)
            {
                bool requestSucceeded = true;
                string serverLog = "Delete request succeeded.";
                callback(requestSucceeded, serverLog);
            }
            else
            {
                bool requestSucceeded = false;
                string serverLog = "Delete request failed.";
                callback(requestSucceeded, serverLog);
            }
        }
    }
}

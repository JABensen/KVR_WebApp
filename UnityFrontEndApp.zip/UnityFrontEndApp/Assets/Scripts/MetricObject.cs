using System.Collections.Generic;
using TMPro;
using UnityEngine;
using KVR;

namespace KVR
{
    public enum TextObjects
    {
        Student = 0,
        Task = 1,
        Event = 2,
        Time = 3,
    }
}

public class MetricObject : MonoBehaviour
{
    private List<TextMeshProUGUI> textComponents = new List<TextMeshProUGUI>();

    private void Awake()
    {
        this.textComponents.Add(this.gameObject.transform.GetChild((int)TextObjects.Student).gameObject.GetComponent<TextMeshProUGUI>());
        this.textComponents.Add(this.gameObject.transform.GetChild((int)TextObjects.Task).gameObject.GetComponent<TextMeshProUGUI>());
        this.textComponents.Add(this.gameObject.transform.GetChild((int)TextObjects.Event).gameObject.GetComponent<TextMeshProUGUI>());
        this.textComponents.Add(this.gameObject.transform.GetChild((int)TextObjects.Time).gameObject.GetComponent<TextMeshProUGUI>());
    }

    public void UpdateTextComponent(int index, string newText)
    {
        this.textComponents[index].text = newText;
    }
}

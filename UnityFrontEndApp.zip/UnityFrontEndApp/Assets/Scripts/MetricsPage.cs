using System.Collections.Generic;
using UnityEngine;
using Defective.JSON;
using KVR;
using TMPro;
using Unity.VisualScripting;

public class MetricsPage : MenuPage
{
    [SerializeField] private GameObject contentObject; //Reference to the gameObject who's children are the gameObjects that display metrics.
    private List<MetricObject> activeMetricObjects = new List<MetricObject>(); //List of active metrics.  The type in the list is the script attached to each of the contentObject's children in the hierarchy.
    [SerializeField] private TextMeshProUGUI consoleText;
    public ParentMetricListDTO parentMetrics { get; set; } //Reference to the parent DTO. This is where we store the metric data that is parsed in via web request. 

    private void OnEnable()
    {
        this.parentMetrics = new ParentMetricListDTO(); //We need to construct new objects each time the page is SetActive to trigger a refresh.
        this.parentMetrics.StudentMetrics = new List<StudentMetricsDTO>(); //We need to construct new objects each time the page is SetActive to trigger a refresh.
        if (!string.IsNullOrEmpty(this.MenuContext.UserId))
        {
            this.GetMetrics(); //Initiate the request each time the page is enabled.
        }
    }

    private void OnDisable()
    {
        this.RemoveAllMetricObjects();
    }

    public void GetMetrics()
    {
        RequestReturnDelegate requestReturn = ReturnMetrics; //Delegates of this type allow the NetworkManager's asynchronous coroutines to return data back to the source classes after a web request is made.
        this.MenuContext.NetworkManager.MetricRequestHandler.GetMetrics(requestReturn);
    }

    public void ReturnMetrics(bool requestSucceeded, string serverLog)
    {
        if(requestSucceeded) 
        {
            this.ParseStudentMetrics(serverLog); //If request succeeds, serverLog contains valid json.
            this.consoleText.text = "Metrics parsed successfully.";
        }
        else
        {
            this.consoleText.text = serverLog; //If request fails, display the error message from the server.
        }
    }

    private void ParseStudentMetrics(string serverLog)
    {
        JSONObject parentObject = new JSONObject(serverLog);
        parentObject.GetField("StudentMetrics", studentMetrics =>
        {
            int i = 0;
            foreach (var student in studentMetrics.list)
            {
                this.parentMetrics.StudentMetrics.Add(new StudentMetricsDTO());
                this.parentMetrics.StudentMetrics[i].EventLogs = new List<EventLogDTO>();
                student.GetField("StudentName", studentName =>
                {
                    this.parentMetrics.StudentMetrics[i].StudentName = studentName.stringValue;
                });
                student.GetField("EventLogs", eventLogs =>
                {
                    int j = 0;
                    foreach (var log in eventLogs.list)
                    {
                        this.parentMetrics.StudentMetrics[i].EventLogs.Add(new EventLogDTO());
                        log.GetField("Id", Id =>
                        {
                            this.parentMetrics.StudentMetrics[i].EventLogs[j].Id = Id.stringValue;
                        });
                        log.GetField("TaskName", TaskName =>
                        {
                            this.parentMetrics.StudentMetrics[i].EventLogs[j].TaskName = TaskName.stringValue;
                        });
                        log.GetField("EventType", EventType =>
                        {
                            this.parentMetrics.StudentMetrics[i].EventLogs[j].EventType = EventType.stringValue;
                        });
                        log.GetField("SecondsIntoTest", SecondsIntoTest =>
                        {
                            this.parentMetrics.StudentMetrics[i].EventLogs[j].SecondsIntoTest = SecondsIntoTest.doubleValue;
                        });
                        j++;
                    }
                });
                i++;
            }
        });
        this.GenerateMetricTables();
    }

    private void GenerateMetricTables()
    {
        foreach(var student in this.parentMetrics.StudentMetrics)
        {
            foreach(var eventLog in student.EventLogs)
            {
                AddMetricObject(student.StudentName, eventLog.TaskName, eventLog.EventType, eventLog.SecondsIntoTest.ToString());
            }
        }
    }

    private void AddMetricObject(string student, string task, string eventType, string time)
    {
        foreach (Transform child in this.contentObject.transform)
        {
            GameObject childGameObject = child.gameObject;
            if (!childGameObject.activeSelf)
            {
                childGameObject.SetActive(true);
                MetricObject metricObject = childGameObject.GetComponent<MetricObject>();
                metricObject.UpdateTextComponent((int)TextObjects.Student, student);
                metricObject.UpdateTextComponent((int)TextObjects.Task, task);
                metricObject.UpdateTextComponent((int)TextObjects.Event, eventType);
                metricObject.UpdateTextComponent((int)TextObjects.Time, time);
                this.activeMetricObjects.Add(metricObject);
                return;
            }
        }
    }

    private void RemoveAllMetricObjects()
    {
        int count = this.activeMetricObjects.Count;
        for(int i = 0; i < count; i++)
        {
            GameObject childGameObject = this.contentObject.transform.GetChild(i).gameObject;
            MetricObject metricObject = childGameObject.GetComponent<MetricObject>();
            metricObject.UpdateTextComponent((int)TextObjects.Student, " ");
            metricObject.UpdateTextComponent((int)TextObjects.Task, " ");
            metricObject.UpdateTextComponent((int)TextObjects.Event, " ");
            metricObject.UpdateTextComponent((int)TextObjects.Time, " ");
            this.activeMetricObjects.Remove(metricObject);
            childGameObject.SetActive(false);
        }
    }
}

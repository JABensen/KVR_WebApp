using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class AccountPage : MenuPage
{
    [SerializeField] private TextMeshProUGUI fullNameTextComponent;
    [SerializeField] private TextMeshProUGUI usernameTextComponent;
    [SerializeField] private TextMeshProUGUI classKeyTextComponent;

    private void OnEnable()
    {
        this.fullNameTextComponent.text = this.MenuContext.FirstName + " " + this.MenuContext.LastName;
        this.usernameTextComponent.text = this.MenuContext.Username;
        this.classKeyTextComponent.text = this.MenuContext.ClassKey;
    }
}

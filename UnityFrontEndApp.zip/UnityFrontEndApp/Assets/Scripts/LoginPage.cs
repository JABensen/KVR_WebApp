using KVR;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using Defective.JSON;

public class LoginPage : MenuPage
{
    [SerializeField] private GameObject loginBox;
    [SerializeField] private GameObject createAccountBox;
    [SerializeField] private TextMeshProUGUI consoleText;

    [SerializeField] private TMP_InputField loginUsernameField;
    [SerializeField] private TMP_InputField loginPasswordField;

    [SerializeField] private TMP_InputField createFirstNameField;
    [SerializeField] private TMP_InputField createLastNameField;
    [SerializeField] private TMP_InputField createUsernameField;
    [SerializeField] private TMP_InputField createPasswordField;
    [SerializeField] private TMP_InputField createConfirmField;

    private string loginUsername;
    private string loginPassword;

    private string createFirstName;
    private string createLastName;
    private string createUsername;
    private string createPassword;
    private string createConfirm;

    private void Awake()
    {
        loginUsernameField.onEndEdit.AddListener(OnEndEditLoginUsername);
        loginPasswordField.onEndEdit.AddListener(OnEndEditLoginPassword);

        createFirstNameField.onEndEdit.AddListener(OnEndEditCreateFirstName);
        createLastNameField.onEndEdit.AddListener(OnEndEditCreateLastName);

        createUsernameField.onEndEdit.AddListener(OnEndEditCreateUsername);
        createPasswordField.onEndEdit.AddListener(OnEndEditCreatePassword);
        createConfirmField.onEndEdit.AddListener(OnEndEditCreateConfirm);
        
        loginBox.SetActive(true);
        createAccountBox.SetActive(false);
    }

    private void OnEnable()
    {
        this.UpdateConsoleText(" ");
    }

    private void OnEndEditLoginUsername(string text)
    {
        loginUsername = text;
    }

    private void OnEndEditLoginPassword(string text)
    {
        loginPassword = text;
    }

    private void OnEndEditCreateFirstName(string text)
    {
        createFirstName = text;
    }

    private void OnEndEditCreateLastName(string text)
    {
        createLastName = text;
    }

    private void OnEndEditCreateUsername(string text)
    {
        createUsername = text;
    }

    private void OnEndEditCreatePassword(string text)
    {
        createPassword = text;
    }

    private void OnEndEditCreateConfirm(string text)
    {
        createConfirm = text;
    }

    public void LoginPressed() //Invoked via button OnClick() event.
    {
        if (string.IsNullOrEmpty(loginUsername) || string.IsNullOrEmpty(loginPassword)) //Simple client-side validation
        {
            string newText = "One or more of the input fields above have been left empty.";
            this.UpdateConsoleText(newText);
        }
        else
        {
            RequestReturnDelegate requestReturn = ReturnLogin;
            this.MenuContext.NetworkManager.AccountRequestHandler.Login(this.loginUsername, this.loginPassword, requestReturn);
        }
    }

    public void ReturnLogin(bool loginSucceeded, string serverLog)
    {
        if (loginSucceeded) //The following code is what creates a "user state" within this application.
        {                   //This data is accessed by the other pages through the MenuContext to display data and formulate web requests.
            var rootObject = new JSONObject(serverLog);
            rootObject.GetField("Id", Id =>
            {
                this.MenuContext.UserId = Id.stringValue;
            });
            rootObject.GetField("Username", Username =>
            {
                this.MenuContext.Username = Username.stringValue;
            });
            rootObject.GetField("FirstName", FirstName =>
            {
                this.MenuContext.FirstName = FirstName.stringValue;
            });
            rootObject.GetField("LastName", LastName =>
            {
                this.MenuContext.LastName = LastName.stringValue;
            });
            rootObject.GetField("ClassKey", ClassKey =>
            {
                this.MenuContext.ClassKey = ClassKey.stringValue;
            });
            this.MenuContext.ChangeActivePage((int)Pages.Account); //After the user has logged in, the context changes to the AccountPage.
        }
        else
        {
            this.consoleText.text = serverLog;
        }
    }

    public void CreateAccountPressed() //Invoked via button OnClick() event.
    {
        if (string.IsNullOrEmpty(createFirstName) || string.IsNullOrEmpty(createLastName) || string.IsNullOrEmpty(createUsername) || string.IsNullOrEmpty(createPassword) || string.IsNullOrEmpty(createConfirm))
        {
            string newText = "One or more of the input fields above have been left empty.";
            this.UpdateConsoleText(newText);
        }
        else if (createPassword != createConfirm)
        {
            string newText = "The password fields do not match.";
            this.UpdateConsoleText(newText);
        }
        else
        {
            RequestReturnDelegate requestReturn = ReturnCreateAccount;
            this.MenuContext.NetworkManager.AccountRequestHandler.CreateAccount(createFirstName, createLastName, createUsername, createPassword, requestReturn);
        }
    }

    public void ReturnCreateAccount(bool createSucceeded, string serverLog)
    {
        if (createSucceeded) //Upon successfully creating an account, the client will automatically use the username and password to initiate a login.  
        {
            this.ToggleToLogin();
            loginUsername = createUsername;
            loginPassword = createPassword;
            LoginPressed();
        }
        else
        {
            this.consoleText.text = serverLog;
        }
    }

    private void UpdateConsoleText(string newText)
    {
        consoleText.text = newText;
    }

    public void ToggleToLogin() //Invoked via button OnClick() event.
    {
        createAccountBox.SetActive(false);
        loginBox.SetActive(true);
    }

    public void ToggleToCreateAccount() //Invoked via button OnClick() event.
    {
        loginBox.SetActive(false);
        createAccountBox.SetActive(true);
    }
}
